/*
 * Programa: Control de 6 LEDs mediante Monitor Serie (Caso ii)
 
 Descricion: Este programa le unha cadea de texto (String) introducida polo
 usuario a traves do Monitor Serie de Arduino. Segundo o texto recibido,
 fai chiscar (acende e apaga cada 500 ms) o LED correspondente conectado
 entre os pins dixitais 12 e 7, empregando bifurcacions if-else if.
 
 Autor: Adrián Busto Nine
 
 Data: 24/11/2026
 */

// Declaracion dos pins dixitais para os seis LEDs
int led1 = 12; // LED Vermello
int led2 = 11; // LED Verde
int led3 = 10; // LED Amarelo
int led4 = 9;  // LED Azul
int led5 = 8;  // LED Branco
int led6 = 7;  // LED Laranxa

// Variable textual de tipo String para gardar a lectura do Monitor Serie
String corLed = ""; 

void setup() {
  // Configuramos os pins 12 ao 7 como saidas dixitais
  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(led3, OUTPUT);
  pinMode(led4, OUTPUT);
  pinMode(led5, OUTPUT);
  pinMode(led6, OUTPUT);

  // Iniciamos a comunicacion serie a 9600 baudios
  Serial.begin(9600);
  
  // Mensaxe inicial de instrucions no Monitor Serie
  Serial.println("Escribe o nome da cor (vermello, verde, amarelo, azul, branco, laranxa):");
}

void loop() {
  // Comprobamos se hai datos disponibeis entrantes no porto serie
  if (Serial.available() > 0) {
    corLed = Serial.readString(); // Lemos a cadea de texto enviada
  }

  // Bifurcacion concatenada para facer chiscar o LED segundo o valor de corLed
  if (corLed == "vermello") {
    digitalWrite(led1, HIGH); // Acende o LED do pin 12
    delay(500);               // Espera 500 ms
    digitalWrite(led1, LOW);  // Apaga o LED do pin 12
    delay(500);               // Espera 500 ms
  } 
  else if (corLed == "verde") {
    digitalWrite(led2, HIGH); // Acende o LED do pin 11
    delay(500);
    digitalWrite(led2, LOW);
    delay(500);
  } 
  else if (corLed == "amarelo") {
    digitalWrite(led3, HIGH); // Acende o LED do pin 10
    delay(500);
    digitalWrite(led3, LOW);
    delay(500);
  } 
  else if (corLed == "laranxa"){
    digitalWrite(led4, HIGH); // Acende o LED do pin 9
    delay(500);
    digitalWrite(led4, LOW);
    delay(500);
  } 
  else if (corLed == "azul"){
    digitalWrite(led5, HIGH); // Acende o LED do pin 8
    delay(500);
    digitalWrite(led5, LOW);
    delay(500);
  } 
  else if (corLed == "branco"){
    digitalWrite(led6, HIGH); // Acende o LED do pin 7
    delay(500);
    digitalWrite(led6, LOW);
    delay(500);
  } 
}