/*
  Programa: Control de 6 LEDs mediante variable textual (Caso 1º)
  
  Descrición: Este programa acende e apaga en intervalos de 500 ms un dos seis
  LEDs conectados aos pins dixitais 12 a 7, en función do valor asignado
  manualmente a unha variable de tipo String mediante estruturas if-else if.
  
  Autor: Adrián Busto Nine
 
  Data: 23/11/2026
 */

// Declaración dos pins dixitais asignados a cada LED
int led1 = 12; // LED Vermello
int led2 = 11; // LED Verde
int led3 = 10; // LED Amarelo
int led4 = 9;  // LED Laranxa
int led5 = 8;  // LED Azúl
int led6 = 7;  // LED Branco
// Variable textual (String) que determina que LED debe chiscar.
// Cambia este valor manualmente por: "vermello", "verde", "amarelo", "azul", "branco" ou "laranxa"
String corLed = "branco"; 

void setup() {
  // Configuración dos pins 12 ao 7 como saídas dixitais (OUTPUT)
  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(led3, OUTPUT);
  pinMode(led4, OUTPUT);
  pinMode(led5, OUTPUT);
  pinMode(led6, OUTPUT);
}

void loop() {
  // Estrutura de bifurcación concatenada (if - else if) para comprobar o texto
  if (corLed == "vermello") {
    digitalWrite(led1, HIGH); // Acende o LED 1 (pin 12)
    delay(500);               // Agarda 500 milisegundos
    digitalWrite(led1, LOW);  // Apaga o LED 1
    delay(500);               // Agarda 500 milisegundos
  } 
  else if (corLed == "verde") {
    digitalWrite(led2, HIGH); // Acende o LED 2 (pin 11)
    delay(500);
    digitalWrite(led2, LOW);
    delay(500);
  } 
  else if (corLed == "amarelo") {
    digitalWrite(led3, HIGH); // Acende o LED 3 (pin 10)
    delay(500);
    digitalWrite(led3, LOW);
    delay(500);
  } 
  else if (corLed == "laranxa") {
    digitalWrite(led4, HIGH); // Acende o LED 4 (pin 9)
    delay(500);
    digitalWrite(led4, LOW);
    delay(500);
  } 
  else if (corLed == "azul") {
    digitalWrite(led5, HIGH); // Acende o LED 5 (pin 8)
    delay(500);
    digitalWrite(led5, LOW);
    delay(500);
  } 
  else if (corLed == "branco") {
    digitalWrite(led6, HIGH); // Acende o LED 6 (pin 7)
    delay(500);
    digitalWrite(led6, LOW);
    delay(500);
  }
}